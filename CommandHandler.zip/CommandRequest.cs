using Noter.Application.Infrastructure.Commanding;

namespace $rootnamespace$
{
    public class $fileinputname$Command : CommandRequestBase<$fileinputname$CommandResult>
    {
    }
}