using Noter.Application.Infrastructure.Commanding;
using System;

namespace $rootnamespace$
{
    public class $fileinputname$CommandResult : CommandResultBase
    {
        public $fileinputname$CommandResult(Guid requestGuid) : base(requestGuid) { }
    }
}