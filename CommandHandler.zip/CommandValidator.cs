using FluentValidation;
using Noter.Application.Infrastructure.Commanding;

namespace $rootnamespace$
{
    public class $fileinputname$CommandValidator : CommandValidatorBase<$fileinputname$Command>
    {
        public $fileinputname$CommandValidator() : base() 
        {
            //RuleFor(n => n.Title).MaximumLength(100).NotEmpty().WithMessage("Item title is required");
        }
    }
}
